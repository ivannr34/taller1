
package pa.taller1Bolero.modelo;

public class ConstantesJuego {
    
}
