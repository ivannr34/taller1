package pa.taller1Bolero.vista;
import javax.swing.*;
import java.awt.*;
import pa.taller1Bolero.modelo.Equipo;
import pa.taller1Bolero.modelo.Jugador;

public class PanelEquipo extends JPanel {
    private Equipo equipo;
    
    public PanelEquipo(Equipo equipo) {

        this.equipo = equipo;

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder(equipo.getNombreEquipo()));

        JPanel panelJugadores = new JPanel(new GridLayout(1, 3));

        for (Jugador jugador : equipo.getJugadores()) {
            panelJugadores.add(new PanelJugador(jugador));
        }

        add(panelJugadores, BorderLayout.CENTER);
    } 
     public void ponerTransparente() {
        setOpaque(false);
        setBackground(new Color(255,255,255,80));
    }
     public void activarEquipo() {
        setOpaque(true);
        setBackground(null);
    }
}
