package pa.taller1Bolero.vista;
import javax.swing.JFrame;
import java.awt.*;
import java.io.File;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import pa.taller1Bolero.modelo.Equipo;

public class VentanaPrincipal extends JFrame {
        private JPanel panelPrincipal;
    private JPanel panelEquipos;
    private JPanel panelEstado;

    private JButton btnPrecargar;
    private JButton btnIniciar;
    private JButton btnSalir;

    private JLabel lblTiempo;
    private JLabel lblIntentos;
    private JLabel lblEmbocada;
    private JLabel lblPuntos;
    
    public VentanaPrincipal () {
        inicializar();
        configurarVentana();

    } 
     private void configurarVentana() {
        setTitle("Juego del Balero - Programación Avanzada");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void inicializar() {

        panelPrincipal = new JPanel(new BorderLayout());

        crearPanelSuperior();
        crearPanelEquipos();
        crearPanelEstado();
        add(panelPrincipal);
    }
        private void crearPanelSuperior() {

        JPanel panelSuperior = new JPanel(new FlowLayout());

        btnPrecargar = new JButton("Precargar Equipos");
        btnIniciar = new JButton("Iniciar Juego");
        btnSalir = new JButton("Salir");

        panelSuperior.add(btnPrecargar);
        panelSuperior.add(btnIniciar);
        panelSuperior.add(btnSalir);

        panelPrincipal.add(panelSuperior, BorderLayout.NORTH);
    }
         private void crearPanelEquipos() {

        panelEquipos = new JPanel();
        panelEquipos.setLayout(new GridLayout(0, 2, 20, 20));

        JScrollPane scroll = new JScrollPane(panelEquipos);
        panelPrincipal.add(scroll, BorderLayout.CENTER);
    }
             private void crearPanelEstado() {

        panelEstado = new JPanel(new GridLayout(2, 2));

        lblTiempo = new JLabel("Tiempo: 0");
        lblIntentos = new JLabel("Intentos: 0");
        lblEmbocada = new JLabel("Embocada: -");
        lblPuntos = new JLabel("Puntos: 0");

        panelEstado.add(lblTiempo);
        panelEstado.add(lblIntentos);
        panelEstado.add(lblEmbocada);
        panelEstado.add(lblPuntos);

        panelPrincipal.add(panelEstado, BorderLayout.SOUTH);
    }
               public File seleccionarArchivo() {

        JFileChooser fileChooser = new JFileChooser();
        int opcion = fileChooser.showOpenDialog(this);

        if (opcion == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        }

        return null;
    }
}