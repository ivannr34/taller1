package pa.taller1Bolero.vista;
import javax.swing.*;
import java.awt.*;
import pa.taller1Bolero.modelo.Jugador;

public class PanelJugador extends JPanel {
    private Jugador jugador;

    public PanelJugador(Jugador jugador) {

        this.jugador = jugador;

        setLayout(new BorderLayout());
        JLabel lblImagen = new JLabel(
                new ImageIcon("src/main/resources/jugador.png")
        );

        JLabel lblNombre = new JLabel(
                jugador.getNombre(),
                SwingConstants.CENTER
        );

        add(lblImagen, BorderLayout.CENTER);
        add(lblNombre, BorderLayout.SOUTH);
    }
     public void resaltarTurno() {
        setBorder(BorderFactory.createLineBorder(Color.RED, 3));
    }
     public void quitarResaltado() {
        setBorder(null);
    }
}
