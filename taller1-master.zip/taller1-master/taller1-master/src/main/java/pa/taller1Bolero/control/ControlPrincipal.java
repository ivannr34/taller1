package pa.taller1Bolero.control;

import pa.taller1Bolero.modelo.*;
import pa.taller1Bolero.vista.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ControlPrincipal {
    private VentanaPrincipal vista;
    private JuegoBalero juego;
    public ControlPrincipal(VentanaPrincipal vista) {
        this.vista = vista;
        inicializarEventos();
    }
}